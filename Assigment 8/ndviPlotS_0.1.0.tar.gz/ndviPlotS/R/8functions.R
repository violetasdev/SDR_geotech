#' NDVI Object Class
#'
#' Generate new object class
#' @export
#' @name ndviClass
#' @return Null
NULL

ndviClass <- setClass("ndvi", slots=c("ndvi","stars"))

#' NDVI Function
#'
#' Calculate NDVI from starts object and return a ndvi object
#' @export
#' @param starobj object of class \code{stars}
#' @param band_dim dimension of the star object with the bands. Default value is 3
#' @name ndvi
#' @return NDVI object with the calculated values in a stars object and the original stars object
#'
#' @import grDevices
#' @import graphics
#' @import stars
#' @import sf

NULL

ndvi<- function(starobj,band_dim=3){
  #Calculate NDVI
  per_band=split(starobj, band_dim)
  ndvi_calculated <- (per_band[4,] - per_band[3,]) / (per_band[4,] + per_band[3,])

  ndviObject<-ndviClass(ndvi=ndvi_calculated,stars=starobj)

  return(ndviObject)
}


#' Plot NDVI
#'
#' Prints a plot for NDVI object for the NDVI@ndvi object slot
#'
#' @param ndviObjectSel stars object to calculate NDVI
#' @param colorsGrey color scale for drawing. By default is a grey scale defined by grey((1:10)/10))
#'
#' @return temporal plot printed locally on memory
#'
#' @import grDevices
#' @import graphics
#' @import methods
#' @import stars
#' @import sf
#'
#' @examples
#' library (stars)
#' library (sf)
#' tif = system.file("tif/L7_ETMs.tif", package = "stars")
#' starobj = read_stars(tif)
#' ndviClass <- setClass("ndvi", slots=c("ndvi","stars"))
#' ndviCalculated=ndvi(starobj)
#' plotndvi(ndviCalculated)
#'
#' @export

#Proposed
plotndvi<-function(ndviObjectSel,colorsGrey=(grey((1:10)/10))){
  plot(ndviObjectSel@ndvi, col=colorsGrey, breaks=c(seq(-1,1,length.out = 11)),main="NDVI Plot")
}

#Solution

##plot.ndvi=function(x,..., breaks=seq(-1,1,length.out = 11),col=grey((1:10)/10))){
##  class(x)<-c("stars")
##  plot(x,...,breaks="equal",col=grey((1:10)/10),main="NDVI Plot")
##
##}
