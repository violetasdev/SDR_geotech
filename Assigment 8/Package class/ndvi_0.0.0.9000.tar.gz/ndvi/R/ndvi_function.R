#' A ndvi Function
#'
#' This function allows you to estimate ndvi index using 2 bands
#' @import stars
#' @importFrom grDevices grey
#' @param data a star object
#' @param red as red band image
#' @param nir as nir band image
#' @keywords ndvi
#' @export
#' @examples
#' tif = system.file("tif/L7_ETMs.tif", package = "stars")
#' ndvi_function(tif)
ndvi_function<-function(data, red=3, nir=4){
  x = read_stars(data)
  bands=split(x, "band")
  red = bands[red]
  nir = bands[nir]
  ndvi = ((nir-red)/(nir+red))
  class(ndvi) <- c("ndvi", "stars")
  return(ndvi)
}

#' plot ndvi objects
#'
#' plot ndvi objects
#' @param x object of class `ndvi`
#' @param col col
#' @param breaks breaks
#' @param main main
#' @param ... ignored
#' @export
#' @examples
#' tif = system.file("tif/L7_ETMs.tif", package = "stars")
#' x = ndvi_function(tif)
#' plot(x)
plot.ndvi = function(x, ... , breaks = seq(-1,1,0.2), col=grey((1:10)/10), main="ndvi") {
  NextMethod(.Generic, breaks = breaks, col = col, main = main, ...)
}
