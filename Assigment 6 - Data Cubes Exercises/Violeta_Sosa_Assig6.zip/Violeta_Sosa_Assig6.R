#Assigment 6

#NDVI, normalized differenced vegetation index, is computed as (NIR-R)/(NIR+R), 
#with NIR the near infrared and R the red band. Read the L7_ETMs.tif file into object x, and 
#distribute the band dimensions over attributes by split(x, "band"). 
#Then, compute NDVI by using an expression that uses the NIR (band 4) and R (band 3) attributes directly.


#plot(x, rgb = c(4,3,2), main = "False color (NIR-R-G)") # false color

tif = system.file("tif/L7_ETMs.tif", package = "stars")
library(stars)
x = read_stars(tif)
x
plot(x)
per_band=split(x, "band")

ndvi_brazil <- (per_band[4,] - per_band[3,]) / (per_band[4,] + per_band[3,])
plot(ndvi_brazil,main = "NDVI of Brazil")

#Another approach
ndvi = function(x) (x[4]-x[3])/(x[4]+x[3])
ndvi_brazil2<-st_apply(x, c("x", "y"), ndvi)
plot(ndvi_brazil2)

#What are the differences?
graphics.off() 
par(mfrow=c(2,2))
plot(ndvi_brazil, main="NDVI Brazil")
#plot(ndvi_brazil2, add=TRUE)

#Compute NDVI for the S2 image, using st_apply and an a function 
#ndvi = function(x) (x[4]-x[3])/(x[4]+x[3]). Plot the result, 
#and write the result to a GeoTIFF. Explain the difference in runtime between plotting and writing.

install.packages("starsdata", repos = "http://pebesma.staff.ifgi.de", type = "source")

granule = system.file("sentinel/S2A_MSIL1C_20180220T105051_N0206_R051_T32ULE_20180221T134037.zip", package = "starsdata")
base_name = strsplit(basename(granule), ".zip")[[1]]
s2 = paste0("SENTINEL2_L1C:/vsizip/", granule, "/", base_name, ".SAFE/MTD_MSIL1C.xml:10m:EPSG_32632")
(p = read_stars(s2, proxy = TRUE))

ndvi = function(x) (x[4]-x[3])/(x[4]+x[3])
ndvi_s2<-st_apply(p, c("x", "y"), ndvi)
plot(ndvi_s2)


start.time <- Sys.time()
write_stars(p, "p2.tif")
end.time <- Sys.time()
time.takenG <- end.time - start.time
paste(time.takenG,units(time.takenG))


start.time <- Sys.time()
plot(ndvi_s2)
end.time <- Sys.time()
time.takenP <- end.time - start.time
store<-toString(time.takenP)
store
#The time for the GeoTIFF generation is time.takenG and for the plot time.takenP . 
#These differences are because of the pixel size and image resolution for the outputs. Meanwhile the plot shows
#a basic result that renders acording zoom levels, the TIFF image (apart from all the metadata stored) contains
#the complete resolution values for the imag


#Use st_transform to transform the stars object read from L7_ETMs.tif to EPSG 4326. 
#Print the object. Is this a regular grid? Plot the first band using arguments axes=TRUE and borders=NA, 
#and explain why this takes such a long time.
l7_transform<-st_transform(x,crs =4326)
per_band_trans=split(l7_transform, "band")


#It is not a regular grid. It is a curvilinear grid. 

start.time <- Sys.time()
plot(l7_transform[,,,1],axes=TRUE,borders=NA)
end.time <- Sys.time()
time.takenL7 <- end.time - start.time
time.takenL7



#It takes a lot of time because is computing the values of each pixel to render it properly in 
# a lower resolution by scaling the result to fit the user screen. First time it took 2 mins, second time 15 segs, 
#this may be due cache.

#Use st_warp to warp the L7_ETMs.tif object to EPSG 4326, and plot the resulting object 
#with axes=TRUE. 
#Why is the plot created much faster than after st_transform?
library(sf)
warp_trans<-st_warp(x,crs=4326)
plot(warp_trans[,,,1],axes=TRUE,borders=NA)

start.time <- Sys.time()
plot(warp_trans[,,,1],axes=TRUE,borders=NA)
end.time <- Sys.time()
time.takenL7 <- end.time - start.time
time.takenL7

#This plot is much faster, it only took time.takenL7 . 
#This is because the st_transform function leads to lossless transformation. It keeps the image data integration.
#For gridded spatial data, a curvilinear grid with transformed grid cell (centers) is returned.
#In the other hand, st_wraps converts the object into a regular grid in the new CRS. This implies
#that a resampling is done over the image, causing data lose that can not be reversed [1]

plot(l7_transform[,,,1],axes=TRUE,borders=NA)
